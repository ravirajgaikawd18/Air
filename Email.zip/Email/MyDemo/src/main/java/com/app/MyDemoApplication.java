package com.app;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyDemoApplication.class, args);
	 
		System.out.println("Prepare to send msg");
	 String message = "Hello, This is Testing Email";
	 String subject = "EMail : Confirm";
	 String to = "kajalghule111@gmail.com";
	 String from = "tj.lakade@gmail.com";
	 
	 sendEmail(message, subject,to,from);
	 
	}

	// this is resposnsible to send message
	private static void sendEmail(String message, String subject, String to, String from) {
		// TODO Auto-generated method stub
	    	
		String host = "smtp.gmail.com";
		
		Properties properties = System.getProperties();
	    System.out.println("PROPERTIES"+properties);
	    
	    properties.put("mail.smtp.host",host);
	    properties.put("mail.smtp.port","465");
	    properties.put("mail.smtp.ssl.enable","true");
	    properties.put("mail.smtp.auth","true");
	    
	  Session session = Session.getInstance(properties, new Authenticator()
			  {

				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					// TODO Auto-generated method stub
					return  new PasswordAuthentication("tj.lakade@gmail.com","hehifgmydudkudrf");         	
			  }		          
			  });
	
	     session.setDebug(true);
	  // composing Message
	        MimeMessage m = new MimeMessage(session);
	        try {
				m.setFrom(from);
				
				// add recepient
				m.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                
				m.setSubject("Adding Text to ...");
				m.setText(message);
				
				// sending a Message using Transport class
				Transport.send(m);
				System.out.println("Email Sent Successfully....");
	        } catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
