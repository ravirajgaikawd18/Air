package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.ITicketRepository;
import com.app.entity.Booking;
import com.app.entity.Flight;
import com.app.entity.Ticket;

@Service
@Transactional
public class TicketServiceImpl implements ITicketService {

	@Autowired
	private ITicketRepository ticketRepo;
	
	@Override
	public Ticket addTicketDetails(Ticket transientTicket) {
		// TODO Auto-generated method stub
		return ticketRepo.save(transientTicket);
	}

	@Override
	public Ticket getTicketByTicketNo(Long ticketNo) {
		// TODO Auto-generated method stub
		return ticketRepo.findById(ticketNo).orElseThrow();
	}

	@Override
	public String invalidateTicketByTicketNo(Long ticketNo) {
		// TODO Auto-generated method stub
		Ticket fromDB = ticketRepo.findById(ticketNo).orElseThrow();
		if(fromDB != null) {
			fromDB.setIsValid(false);
			return "ticket invalidated";
		}
		return "failure";
	}

	@Override
	public List<Ticket> getTicketsByBookingNo(Booking bookingNo) {
		// TODO Auto-generated method stub
		return ticketRepo.findByBookingNo(bookingNo);
	}

	@Override
	public List<Ticket> getTicketsByFlightId(Flight flightId) {
		// TODO Auto-generated method stub
		return ticketRepo.findByFlightId(flightId);
	}

}
