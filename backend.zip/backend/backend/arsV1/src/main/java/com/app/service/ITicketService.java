package com.app.service;

import java.util.List;

import com.app.entity.Booking;
import com.app.entity.Flight;
import com.app.entity.Ticket;

public interface ITicketService {

	//method to add booking details
		Ticket addTicketDetails(Ticket transientTicket);
		
		Ticket getTicketByTicketNo(Long ticketNo);
		
		String invalidateTicketByTicketNo(Long ticketNo);
		
		List<Ticket> getTicketsByBookingNo(Booking bookingNo);
		
		List<Ticket> getTicketsByFlightId(Flight flightId);
}
