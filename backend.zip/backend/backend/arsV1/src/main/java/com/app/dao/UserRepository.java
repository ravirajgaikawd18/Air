package com.app.dao;

public class UserRepository /* implements IUserRepository */ {

}
