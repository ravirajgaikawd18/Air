package com.app.dao;

public class TokenRepository {

}
