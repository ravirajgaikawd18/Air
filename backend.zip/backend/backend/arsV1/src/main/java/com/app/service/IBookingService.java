package com.app.service;

import com.app.entity.Booking;

public interface IBookingService {

	//method to add booking details
	Booking addBookingDetails(Booking transientBooking);
	
	Booking getBookingByBookingNo(Long bookingNo);
	
	String invalidateBookingByBookingNo(Long bookingNo);
	
	String changePaymentStatusByBookingNo(Long bookingNo);
}
