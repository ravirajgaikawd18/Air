package com.app.dao;

public class BookingRepository {

}
