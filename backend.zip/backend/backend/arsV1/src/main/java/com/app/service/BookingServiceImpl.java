package com.app.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IBookingRepository;
import com.app.entity.Booking;

@Service
@Transactional
public class BookingServiceImpl implements IBookingService {

	@Autowired
	private IBookingRepository bookingRepo;
	
	@Override
	public Booking addBookingDetails(Booking transientBooking) {
		// TODO Auto-generated method stub
		return bookingRepo.save(transientBooking);
	}

	@Override
	public Booking getBookingByBookingNo(Long bookingNo) {
		// TODO Auto-generated method stub
		return bookingRepo.findById(bookingNo).orElseThrow();
	}

	@Override
	public String invalidateBookingByBookingNo(Long bookingNo) {
		// TODO Auto-generated method stub
		Booking fromDB = bookingRepo.findById(bookingNo).orElseThrow();
		if(fromDB != null) {
			fromDB.setIsValid(false);
			return "booking invalidated";
		}
		return "failure";
	}

	@Override
	public String changePaymentStatusByBookingNo(Long bookingNo) {
		// TODO Auto-generated method stub
		Booking fromDB = bookingRepo.findById(bookingNo).orElseThrow();
		if(fromDB != null) {
			fromDB.setPayStatus(true);
			return "payment successfull";
		}
		return "payment failed";
	}

}
