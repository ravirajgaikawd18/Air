package com.app.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponseDto;
import com.app.entity.User;
import com.app.entity.Booking;
import com.app.entity.Flight;
import com.app.entity.Passenger;
import com.app.entity.Payment;
import com.app.entity.Ticket;
import com.app.service.IBookingService;
import com.app.service.IFlightService;
import com.app.service.IPassengerService;
import com.app.service.IPaymentService;
import com.app.service.ITicketService;

@RestController
@RequestMapping("/psgr")
@CrossOrigin(origins = "http://localhost:3000")
public class PassengerController {


	@Autowired
	private IFlightService flightService;
	
	@Autowired
	private IBookingService bookingService;
	
	@Autowired
	private ITicketService ticketService;
	
	@Autowired
	private IPassengerService psgrService;
	
	@Autowired
	private IPaymentService pmtService;
	
	@PostMapping("/searchflight")
	// render the user on flight_list page
	public ResponseEntity<?> searchBySourceAndDestination(@RequestBody Flight searchFlight)
	{
		System.out.println("inside searchBySourceAndDestination date: " + searchFlight.getTravelDate());
		try {
			List<Flight> avlFlights = flightService.findBySourceAndDestinationForTravelDate(searchFlight.getSource(),
												searchFlight.getDestination(), searchFlight.getTravelDate());
			Map<String, Object> map = new HashMap<String, Object>();
			if(avlFlights.isEmpty())
				map.put("result", "no flights");
			else
				map.put("result", avlFlights);
			
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (RuntimeException e) {
			System.out.println("Error in getFlights " + e);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponseDto(e.getMessage()));
		}
	}
	
	@GetMapping("/booking/{bookingNo}")
	public ResponseEntity<?> getBookingDetails(@PathVariable Long bookingNo) {
		System.out.println("inside getBookingDetails" + bookingNo);
		try {
			Booking b = bookingService.getBookingByBookingNo(bookingNo);
			//how to test if lombok lib is actually working ? : invoke a getter
			return new  ResponseEntity<>(b, HttpStatus.OK);
		} catch (RuntimeException e) {
			System.out.println("Error in getBookingDetails "+ e);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).
					body(new ApiResponseDto(e.getMessage()));
		}
	}

	@PostMapping("/addbooking")
	public ResponseEntity<?> addBookingDetails(@RequestBody @Valid Booking transientBooking){	// @RequestBody : unmarshalling (json ---> java)
		
		System.out.println("inside addBookingDetails " + transientBooking);
		try {
			transientBooking.setBookingTime(LocalDateTime.now());
			return new ResponseEntity<>(bookingService.addBookingDetails(transientBooking), HttpStatus.CREATED);
		} catch(RuntimeException e) {
			System.out.println("Error in addBookingDetails method " + e);
			//send api resp (DTO) wrapped in the resp entity
			//return new ResponseEntity<>(new ApiResponseDto(e.getCause().getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
									.body(new ApiResponseDto(e.getCause().getMessage()));
		}
	}
	
	@GetMapping("/invalidatebooking/{bookingNo}")
	public ResponseEntity<?> invalidateBooking(@PathVariable Long bookingNo){
		System.out.println("inside invalidateBooking: " + bookingNo);
		try {
			Map<String, String> map = new HashMap<String, String>();
			String message = bookingService.invalidateBookingByBookingNo(bookingNo);
			map.put("message", message);
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch(RuntimeException e) {
			System.out.println("Error in updateFlight method " + e);
			//send api resp (DTO) wrapped in the resp entity
			//return new ResponseEntity<>(new ApiResponseDto(e.getCause().getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
									.body(new ApiResponseDto(e.getCause().getMessage()));
		}
	}
	@PostMapping("/makepayment")
	public ResponseEntity<?> makePayment(@RequestBody Payment pmt){
		System.out.println("inside makePayment: " + pmt);
		try {
			Map<String, Object> map = new HashMap<>();
			
			int txId = (int)(Math.floor((Math.random())*100000000));
			pmt.setTxId(txId);
			pmt.setTxDateTime(LocalDateTime.now());
			pmt.setTxStatus(true);
			
			Payment persistentPmt = pmtService.addPaymentDetails(pmt);
			
			String message = bookingService.changePaymentStatusByBookingNo(persistentPmt.getBookingNo().getBookingNo());
			map.put("result", persistentPmt);
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch(RuntimeException e) {
			System.out.println("Error in makepayment method " + e);
			//send api resp (DTO) wrapped in the resp entity
			//return new ResponseEntity<>(new ApiResponseDto(e.getCause().getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
									.body(new ApiResponseDto(e.getCause().getMessage()));
		}
	}
	
	@GetMapping("/ticket/{ticketNo}")
	public ResponseEntity<?> getTicketDetails(@PathVariable Long ticketNo) {
		System.out.println("inside getTicketDetails" + ticketNo);
		try {
			Ticket t = ticketService.getTicketByTicketNo(ticketNo);
			//how to test if lombok lib is actually working ? : invoke a getter
			return new  ResponseEntity<>(t, HttpStatus.OK);
		} catch (RuntimeException e) {
			System.out.println("Error in getTicketDetails "+ e);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).
					body(new ApiResponseDto(e.getMessage()));
		}
	}

	@PostMapping("/addticket")
	public ResponseEntity<?> addTicketDetails(@RequestBody @Valid Ticket transientTicket){	// @RequestBody : unmarshalling (json ---> java)
		
		System.out.println("inside addTicketDetails " + transientTicket);
		try {
			return new ResponseEntity<>(ticketService.addTicketDetails(transientTicket), HttpStatus.CREATED);
		} catch(RuntimeException e) {
			System.out.println("Error in addNewUser method " + e);
			//send api resp (DTO) wrapped in the resp entity
			//return new ResponseEntity<>(new ApiResponseDto(e.getCause().getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
									.body(new ApiResponseDto(e.getCause().getMessage()));
		}
	}
	
	@GetMapping("/invalidateTicket/{ticketNo}")
	public ResponseEntity<?> invalidateTicket(@PathVariable Long ticketNo){
		System.out.println("inside invalidateTicket: " + ticketNo);
		try {
			Map<String, String> map = new HashMap<String, String>();
			String message = ticketService.invalidateTicketByTicketNo(ticketNo);
			map.put("message", message);
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch(RuntimeException e) {
			System.out.println("Error in updateFlight method " + e);
			//send api resp (DTO) wrapped in the resp entity
			//return new ResponseEntity<>(new ApiResponseDto(e.getCause().getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
									.body(new ApiResponseDto(e.getCause().getMessage()));
		}
	}
	
	@PostMapping("/seetickets")
	// render the user on flight_list page
	public ResponseEntity<?> seeTicketsForBookingNo(@RequestBody Booking bookingNo)
	{
		System.out.println("inside seeTicketsForBookingNo date: " + bookingNo);
		try {
			List<Ticket> avlTicket = ticketService.getTicketsByBookingNo(bookingNo);
			Map<String, Object> map = new HashMap<String, Object>();
			if(avlTicket.isEmpty())
				map.put("result", "no tickets");
			else
				map.put("result", avlTicket);
			
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (RuntimeException e) {
			System.out.println("Error in getFlights " + e);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponseDto(e.getMessage()));
		}
	}
	
	@PostMapping("/addpsgr")
	public ResponseEntity<?> addPassengerDetails(@RequestBody @Valid Passenger transientPsgr){	// @RequestBody : unmarshalling (json ---> java)
		
		System.out.println("inside addPassengerDetails " + transientPsgr);
		try {
			return new ResponseEntity<>(psgrService.addPsgrDetails(transientPsgr), HttpStatus.CREATED);
		} catch(RuntimeException e) {
			System.out.println("Error in addPassengerDetails method " + e);
			//send api resp (DTO) wrapped in the resp entity
			//return new ResponseEntity<>(new ApiResponseDto(e.getCause().getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
									.body(new ApiResponseDto(e.getCause().getMessage()));
		}
	}
}
