function Footer(){
    return <div>
        Garuda Airlines
    </div>
}export default Footer;