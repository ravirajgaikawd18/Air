import { Link } from "react-router-dom";
import garuda_logo from "./garuda_logo.jpg";

function Header(){
    return <>
    
    <table>
        <tr>
            <td><img src="garuda_logo"/></td>

            <td>Garuda Airlines...</td>

            <td> <Link to={"/Home"} >Home</Link> |</td>

            <td><Link to={"/About"} >About</Link> |</td>

            <td><Link to={"/Contact"} >Contact</Link> |</td>

            <td><Link to={"/Register"} >Register</Link> |</td>

            <td><Link to={"/Login"} >Login</Link> |</td>

            <td><Link to={"/SearchFlight"} >SearchFlight</Link> |</td>
        </tr>
        </table>
      
    
    
    </>
}
export default Header;