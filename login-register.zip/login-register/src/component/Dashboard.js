import { Link, Route, Routes } from "react-router-dom";
import About from "./About";
import Home  from "./Home";
import Header from "./Header";
import Footer from "./Footer";
import Login from "./Login";
import Contact from "./Contact";
import Register from "./Register";
import Reset from "./Reset";
import SearchFlight from "./SearchFlight";
import garuda_logo from "./garuda_logo.jpg";
    

function Dashboard()
{
    return (<>
    <table>
    <tr>
  <td>
   <Header 
   About={About}
   Contact={Contact}
   Register={Register}
   Login={Login}
   SearchFlight={SearchFlight}
   ></Header>
</td>
</tr>
   <hr></hr>

   <tr>
    <td>
    <Link to={"/Home"} >Home</Link> <br></br> <br></br> 
   <Link to={"/About"} >About</Link> <br></br> <br></br>
   <Link to={"/Contact"} >Contact</Link> <br></br> <br></br>
   <Link to={"/Register"} >Register</Link> <br></br> <br></br>
    <Link to={"/Login"} >Login</Link> <br></br> <br></br> 
    <Link to={"/SearchFlight"} >SearchFlight</Link> <br></br> <br></br> 
    
  <Routes>
    <Route path="/" element={<Home />}></Route>
    <Route exact path="/Home"
    element={<Home></Home>}></Route>
     <Route exact path="/About"
    element={<About></About>}></Route>
    <Route exact path="/Contact"
    element={<Contact></Contact>}></Route>
    <Route exact path="/Register"
    element={<Register></Register>}></Route>
    <Route exact path="/Login"
    element={<Login></Login>}></Route>
    <Route  path="/Reset" element={<Reset/>}/>
    <Route  path="/SearchFlight" element={<SearchFlight/>}/>
   </Routes> 
   </td>
   <td>


   </td>

   <td>
    <src img="garuda_logo.jpg"></src>
   </td>
    </tr>

   <hr></hr>
  <Footer>
     <h3>@Copyright Garuda Airways(Dinesh,Suhaas,Prateek,Deepanshu)</h3>
  </Footer>

  </table>
    </>
    )
   
}
export default Dashboard;