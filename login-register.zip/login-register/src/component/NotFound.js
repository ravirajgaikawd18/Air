function NotFound()
{
    return <h1>
        Resource you are looking for .. does not exist!
    </h1>;
}

export default NotFound;